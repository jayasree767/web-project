import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Rocket, 
  Download, 
  Upload, 
  Save, 
  RotateCcw, 
  Moon, 
  Sun,
  Zap,
  Droplets,
  Thermometer
} from "lucide-react";

interface NavigationBarProps {
  onSave: () => void;
  onLoad: () => void;
  onExport: () => void;
  onReset: () => void;
}

interface SystemStatus {
  power: number;
  oxygen: number;
  temperature: number;
}

export default function NavigationBar({
  onSave,
  onLoad,
  onExport,
  onReset
}: NavigationBarProps) {
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // Mock system status - in real app this would come from props or context
  const systemStatus: SystemStatus = {
    power: 87,
    oxygen: 92,
    temperature: 22
  };

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
    console.log("Theme toggled:", !isDarkMode ? 'dark' : 'light');
  };

  const getStatusColor = (value: number, type: 'power' | 'oxygen' | 'temperature') => {
    if (type === 'temperature') {
      return value >= 18 && value <= 25 ? 'text-space-green' : 'text-space-orange';
    }
    if (value >= 80) return 'text-space-green';
    if (value >= 60) return 'text-space-orange';
    return 'text-destructive';
  };

  return (
    <nav className="flex items-center justify-between p-4 border-b bg-card">
      {/* Logo and Title */}
      <div className="flex items-center gap-3">
        <div className="p-2 bg-primary/10 rounded-lg">
          <Rocket className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Space Habitat Designer</h1>
          <p className="text-sm text-muted-foreground">Interactive prototype v1.0</p>
        </div>
      </div>

      {/* System Status */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Zap className={`w-4 h-4 ${getStatusColor(systemStatus.power, 'power')}`} />
            <span className="font-mono">{systemStatus.power}%</span>
          </div>
          <div className="flex items-center gap-2">
            <Droplets className={`w-4 h-4 ${getStatusColor(systemStatus.oxygen, 'oxygen')}`} />
            <span className="font-mono">{systemStatus.oxygen}%</span>
          </div>
          <div className="flex items-center gap-2">
            <Thermometer className={`w-4 h-4 ${getStatusColor(systemStatus.temperature, 'temperature')}`} />
            <span className="font-mono">{systemStatus.temperature}°C</span>
          </div>
        </div>
        <div className="w-px h-6 bg-border" />
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => {
            onSave();
            console.log("Save habitat design");
          }}
          data-testid="button-save"
        >
          <Save className="w-4 h-4 mr-2" />
          Save
        </Button>
        
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => {
            onLoad();
            console.log("Load habitat design");
          }}
          data-testid="button-load"
        >
          <Upload className="w-4 h-4 mr-2" />
          Load
        </Button>
        
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => {
            onExport();
            console.log("Export habitat design");
          }}
          data-testid="button-export"
        >
          <Download className="w-4 h-4 mr-2" />
          Export
        </Button>
        
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => {
            onReset();
            console.log("Reset habitat design");
          }}
          data-testid="button-reset"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset
        </Button>
        
        <div className="w-px h-6 bg-border mx-2" />
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          data-testid="button-theme-toggle"
        >
          {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </Button>
      </div>
    </nav>
  );
}