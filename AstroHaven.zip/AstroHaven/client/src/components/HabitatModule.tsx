import { Home, Beaker, Package, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

export type ModuleType = "living" | "lab" | "storage" | "lifesupport";

interface HabitatModuleProps {
  type: ModuleType;
  id: string;
  position: { x: number; y: number };
  isSelected?: boolean;
  isDragging?: boolean;
  onSelect?: (id: string) => void;
  onDragStart?: (id: string, position: { x: number; y: number }) => void;
  onDrag?: (id: string, position: { x: number; y: number }) => void;
  onDragEnd?: (id: string, position: { x: number; y: number }) => void;
}

const moduleConfig = {
  living: {
    icon: Home,
    color: "bg-space-blue/20 border-space-blue",
    name: "Living Quarters",
    shape: "rounded-lg"
  },
  lab: {
    icon: Beaker,
    color: "bg-space-purple/20 border-space-purple",
    name: "Laboratory",
    shape: "rounded-none"
  },
  storage: {
    icon: Package,
    color: "bg-space-orange/20 border-space-orange",
    name: "Storage",
    shape: "rounded-sm"
  },
  lifesupport: {
    icon: Zap,
    color: "bg-space-green/20 border-space-green",
    name: "Life Support",
    shape: "rounded-full"
  }
};

export default function HabitatModule({
  type,
  id,
  position,
  isSelected = false,
  isDragging = false,
  onSelect,
  onDragStart,
  onDrag,
  onDragEnd
}: HabitatModuleProps) {
  const config = moduleConfig[type];
  const IconComponent = config.icon;

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    onSelect?.(id);
    onDragStart?.(id, position);
    
    const handleMouseMove = (e: MouseEvent) => {
      const newPosition = {
        x: e.clientX - 50, // Center the module on cursor
        y: e.clientY - 50
      };
      onDrag?.(id, newPosition);
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      onDragEnd?.(id, position);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <div
      className={cn(
        "absolute w-24 h-24 border-2 cursor-pointer transition-all duration-200 flex flex-col items-center justify-center gap-1 text-xs font-medium",
        config.color,
        config.shape,
        isSelected && "ring-2 ring-primary ring-offset-2 ring-offset-background",
        isDragging && "scale-110 shadow-lg z-50",
        "hover-elevate"
      )}
      style={{
        left: position.x,
        top: position.y,
        zIndex: isDragging ? 50 : isSelected ? 10 : 1
      }}
      onMouseDown={handleMouseDown}
      data-testid={`module-${type}-${id}`}
    >
      <IconComponent className="w-6 h-6" />
      <span className="text-center leading-tight">{config.name}</span>
    </div>
  );
}