import { useState } from "react";
import HabitatModule, { ModuleType } from "./HabitatModule";
import { cn } from "@/lib/utils";

interface Module {
  id: string;
  type: ModuleType;
  position: { x: number; y: number };
}

interface DesignCanvasProps {
  modules: Module[];
  selectedModuleId?: string;
  onModuleSelect: (id: string) => void;
  onModuleMove: (id: string, position: { x: number; y: number }) => void;
  onModuleAdd: (type: ModuleType, position: { x: number; y: number }) => void;
}

export default function DesignCanvas({
  modules,
  selectedModuleId,
  onModuleSelect,
  onModuleMove,
  onModuleAdd
}: DesignCanvasProps) {
  const [draggedModule, setDraggedModule] = useState<string | null>(null);

  const handleCanvasClick = (e: React.MouseEvent) => {
    // Only handle clicks on the canvas itself, not on modules
    if (e.target === e.currentTarget) {
      onModuleSelect("");
      console.log("Canvas clicked - deselected modules");
    }
  };

  const handleModuleDragStart = (id: string, position: { x: number; y: number }) => {
    setDraggedModule(id);
    console.log("Module drag started:", id);
  };

  const handleModuleDrag = (id: string, position: { x: number; y: number }) => {
    onModuleMove(id, position);
  };

  const handleModuleDragEnd = (id: string, position: { x: number; y: number }) => {
    setDraggedModule(null);
    console.log("Module drag ended:", id, position);
  };

  return (
    <div 
      className={cn(
        "relative flex-1 bg-background border border-border overflow-hidden",
        "bg-[radial-gradient(circle_at_1px_1px,_theme(colors.muted.foreground/0.3)_1px,_transparent_0)] bg-[length:20px_20px]"
      )}
      onClick={handleCanvasClick}
      data-testid="design-canvas"
    >
      {/* Grid overlay */}
      <div className="absolute inset-0 opacity-20">
        <svg width="100%" height="100%" className="pointer-events-none">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Canvas content */}
      <div className="absolute inset-0">
        {modules.map((module) => (
          <HabitatModule
            key={module.id}
            id={module.id}
            type={module.type}
            position={module.position}
            isSelected={selectedModuleId === module.id}
            isDragging={draggedModule === module.id}
            onSelect={onModuleSelect}
            onDragStart={handleModuleDragStart}
            onDrag={handleModuleDrag}
            onDragEnd={handleModuleDragEnd}
          />
        ))}
      </div>

      {/* Canvas info overlay */}
      {modules.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-muted-foreground">
            <p className="text-lg font-medium mb-2">Start Designing Your Habitat</p>
            <p className="text-sm">Drag modules from the palette to begin</p>
          </div>
        </div>
      )}
    </div>
  );
}