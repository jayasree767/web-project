import { Home, Beaker, Package, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ModuleType } from "./HabitatModule";
import { cn } from "@/lib/utils";

interface ModulePaletteProps {
  onModuleSelect: (type: ModuleType) => void;
  selectedType?: ModuleType;
}

const moduleTypes = [
  {
    type: "living" as ModuleType,
    icon: Home,
    name: "Living Quarters",
    description: "Crew sleeping and personal areas",
    color: "text-space-blue border-space-blue/50"
  },
  {
    type: "lab" as ModuleType,
    icon: Beaker,
    name: "Laboratory",
    description: "Research and experimentation",
    color: "text-space-purple border-space-purple/50"
  },
  {
    type: "storage" as ModuleType,
    icon: Package,
    name: "Storage",
    description: "Equipment and supply storage",
    color: "text-space-orange border-space-orange/50"
  },
  {
    type: "lifesupport" as ModuleType,
    icon: Zap,
    name: "Life Support",
    description: "Oxygen, water, and power systems",
    color: "text-space-green border-space-green/50"
  }
];

export default function ModulePalette({ onModuleSelect, selectedType }: ModulePaletteProps) {
  return (
    <Card className="w-72">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="w-5 h-5" />
          Module Palette
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {moduleTypes.map((moduleType) => {
          const IconComponent = moduleType.icon;
          return (
            <Button
              key={moduleType.type}
              variant="outline"
              className={cn(
                "w-full justify-start gap-3 h-auto p-4",
                selectedType === moduleType.type && "bg-accent",
                moduleType.color
              )}
              onClick={() => {
                onModuleSelect(moduleType.type);
                console.log("Selected module type:", moduleType.type);
              }}
              data-testid={`palette-${moduleType.type}`}
            >
              <IconComponent className="w-6 h-6 flex-shrink-0" />
              <div className="text-left">
                <div className="font-medium">{moduleType.name}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  {moduleType.description}
                </div>
              </div>
            </Button>
          );
        })}
        
        <div className="pt-4 border-t">
          <p className="text-xs text-muted-foreground">
            Select a module type and click on the canvas to place it
          </p>
        </div>
      </CardContent>
    </Card>
  );
}