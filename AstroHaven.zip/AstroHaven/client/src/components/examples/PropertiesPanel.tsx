import { useState } from "react";
import PropertiesPanel from '../PropertiesPanel';

export default function PropertiesPanelExample() {
  const [selectedModule, setSelectedModule] = useState({
    id: "test-module",
    type: "living" as const,
    position: { x: 150, y: 200 }
  });

  const handleModuleUpdate = (id: string, updates: any) => {
    setSelectedModule(prev => ({ ...prev, ...updates }));
  };

  const handleModuleDelete = (id: string) => {
    console.log("Delete module:", id);
    setSelectedModule(undefined as any);
  };

  return (
    <div className="w-fit">
      <PropertiesPanel
        selectedModule={selectedModule}
        onModuleUpdate={handleModuleUpdate}
        onModuleDelete={handleModuleDelete}
      />
    </div>
  );
}