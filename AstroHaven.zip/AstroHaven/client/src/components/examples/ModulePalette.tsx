import { useState } from "react";
import ModulePalette from '../ModulePalette';
import { ModuleType } from '../HabitatModule';

export default function ModulePaletteExample() {
  const [selectedType, setSelectedType] = useState<ModuleType>();

  return (
    <div className="w-fit">
      <ModulePalette
        onModuleSelect={setSelectedType}
        selectedType={selectedType}
      />
    </div>
  );
}