import NavigationBar from '../NavigationBar';

export default function NavigationBarExample() {
  const handleSave = () => console.log("Save triggered");
  const handleLoad = () => console.log("Load triggered");
  const handleExport = () => console.log("Export triggered");
  const handleReset = () => console.log("Reset triggered");

  return (
    <div className="w-full">
      <NavigationBar
        onSave={handleSave}
        onLoad={handleLoad}
        onExport={handleExport}
        onReset={handleReset}
      />
    </div>
  );
}