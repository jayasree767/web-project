import { useState } from "react";
import DesignCanvas from '../DesignCanvas';
import { ModuleType } from '../HabitatModule';

interface Module {
  id: string;
  type: ModuleType;
  position: { x: number; y: number };
}

export default function DesignCanvasExample() {
  const [modules, setModules] = useState<Module[]>([
    { id: "1", type: "living", position: { x: 100, y: 100 } },
    { id: "2", type: "lab", position: { x: 200, y: 150 } },
    { id: "3", type: "storage", position: { x: 150, y: 250 } }
  ]);
  const [selectedId, setSelectedId] = useState<string>("");

  const handleModuleMove = (id: string, position: { x: number; y: number }) => {
    setModules(prev => prev.map(m => 
      m.id === id ? { ...m, position } : m
    ));
  };

  const handleModuleAdd = (type: ModuleType, position: { x: number; y: number }) => {
    const newModule: Module = {
      id: Date.now().toString(),
      type,
      position
    };
    setModules(prev => [...prev, newModule]);
  };

  return (
    <div className="w-full h-96">
      <DesignCanvas
        modules={modules}
        selectedModuleId={selectedId}
        onModuleSelect={setSelectedId}
        onModuleMove={handleModuleMove}
        onModuleAdd={handleModuleAdd}
      />
    </div>
  );
}