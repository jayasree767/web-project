import { useState } from "react";
import HabitatModule from '../HabitatModule';

export default function HabitatModuleExample() {
  const [selectedId, setSelectedId] = useState<string>("");
  const [position, setPosition] = useState({ x: 100, y: 100 });

  return (
    <div className="w-full h-96 relative bg-background border rounded-lg">
      <HabitatModule
        id="example-living"
        type="living"
        position={position}
        isSelected={selectedId === "example-living"}
        onSelect={setSelectedId}
        onDrag={(id, newPos) => setPosition(newPos)}
        onDragStart={(id) => console.log("Drag started:", id)}
        onDragEnd={(id, pos) => console.log("Drag ended:", id, pos)}
      />
    </div>
  );
}