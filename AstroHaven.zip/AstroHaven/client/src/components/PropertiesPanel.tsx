import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Trash2, Settings } from "lucide-react";
import { ModuleType } from "./HabitatModule";

interface Module {
  id: string;
  type: ModuleType;
  position: { x: number; y: number };
}

interface PropertiesPanelProps {
  selectedModule?: Module;
  onModuleDelete: (id: string) => void;
  onModuleUpdate: (id: string, updates: Partial<Module>) => void;
}

const moduleSpecs = {
  living: {
    capacity: "4 crew",
    power: "2.5 kW",
    mass: "15 tons",
    volume: "120 m³"
  },
  lab: {
    capacity: "2 researchers",
    power: "4.0 kW", 
    mass: "12 tons",
    volume: "80 m³"
  },
  storage: {
    capacity: "50 tons cargo",
    power: "0.5 kW",
    mass: "8 tons",
    volume: "200 m³"
  },
  lifesupport: {
    capacity: "20 crew",
    power: "8.0 kW",
    mass: "25 tons",
    volume: "60 m³"
  }
};

export default function PropertiesPanel({
  selectedModule,
  onModuleDelete,
  onModuleUpdate
}: PropertiesPanelProps) {
  if (!selectedModule) {
    return (
      <Card className="w-80">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Properties
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-8">
            <Settings className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Select a module to view its properties</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const specs = moduleSpecs[selectedModule.type];

  return (
    <Card className="w-80">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Module Properties
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Module Info */}
        <div>
          <Label className="text-sm font-medium">Module Type</Label>
          <Badge variant="outline" className="mt-2">
            {selectedModule.type.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
          </Badge>
        </div>

        {/* Position */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Position</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="pos-x" className="text-xs text-muted-foreground">X</Label>
              <Input
                id="pos-x"
                type="number"
                value={Math.round(selectedModule.position.x)}
                onChange={(e) => {
                  const x = parseInt(e.target.value) || 0;
                  onModuleUpdate(selectedModule.id, {
                    position: { ...selectedModule.position, x }
                  });
                  console.log("Updated module position X:", x);
                }}
                data-testid="input-position-x"
              />
            </div>
            <div>
              <Label htmlFor="pos-y" className="text-xs text-muted-foreground">Y</Label>
              <Input
                id="pos-y"
                type="number"
                value={Math.round(selectedModule.position.y)}
                onChange={(e) => {
                  const y = parseInt(e.target.value) || 0;
                  onModuleUpdate(selectedModule.id, {
                    position: { ...selectedModule.position, y }
                  });
                  console.log("Updated module position Y:", y);
                }}
                data-testid="input-position-y"
              />
            </div>
          </div>
        </div>

        {/* Specifications */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Specifications</Label>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <span className="text-muted-foreground">Capacity:</span>
              <div className="font-mono">{specs.capacity}</div>
            </div>
            <div>
              <span className="text-muted-foreground">Power:</span>
              <div className="font-mono">{specs.power}</div>
            </div>
            <div>
              <span className="text-muted-foreground">Mass:</span>
              <div className="font-mono">{specs.mass}</div>
            </div>
            <div>
              <span className="text-muted-foreground">Volume:</span>
              <div className="font-mono">{specs.volume}</div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 border-t">
          <Button
            variant="destructive"
            size="sm"
            className="w-full"
            onClick={() => {
              onModuleDelete(selectedModule.id);
              console.log("Deleted module:", selectedModule.id);
            }}
            data-testid="button-delete-module"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete Module
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}