import { useState } from "react";
import NavigationBar from "@/components/NavigationBar";
import ModulePalette from "@/components/ModulePalette";
import DesignCanvas from "@/components/DesignCanvas";
import PropertiesPanel from "@/components/PropertiesPanel";
import { ModuleType } from "@/components/HabitatModule";

interface Module {
  id: string;
  type: ModuleType;
  position: { x: number; y: number };
}

export default function HabitatDesigner() {
  const [modules, setModules] = useState<Module[]>([
    // Start with a few example modules
    { id: "initial-1", type: "living", position: { x: 200, y: 150 } },
    { id: "initial-2", type: "lifesupport", position: { x: 350, y: 200 } }
  ]);
  
  const [selectedModuleId, setSelectedModuleId] = useState<string>("");
  const [selectedPaletteType, setSelectedPaletteType] = useState<ModuleType>();

  const selectedModule = modules.find(m => m.id === selectedModuleId);

  // Canvas handlers
  const handleCanvasClick = (e: React.MouseEvent) => {
    if (selectedPaletteType && e.target === e.currentTarget) {
      const rect = (e.target as HTMLElement).getBoundingClientRect();
      const position = {
        x: e.clientX - rect.left - 48, // Center module on click
        y: e.clientY - rect.top - 48
      };
      
      const newModule: Module = {
        id: `module-${Date.now()}`,
        type: selectedPaletteType,
        position
      };
      
      setModules(prev => [...prev, newModule]);
      setSelectedModuleId(newModule.id);
      setSelectedPaletteType(undefined);
      console.log("Added new module:", newModule);
    }
  };

  const handleModuleSelect = (id: string) => {
    setSelectedModuleId(id);
    if (!id) setSelectedPaletteType(undefined);
  };

  const handleModuleMove = (id: string, position: { x: number; y: number }) => {
    setModules(prev => prev.map(m => 
      m.id === id ? { ...m, position } : m
    ));
  };

  const handleModuleAdd = (type: ModuleType, position: { x: number; y: number }) => {
    const newModule: Module = {
      id: `module-${Date.now()}`,
      type,
      position
    };
    setModules(prev => [...prev, newModule]);
    setSelectedModuleId(newModule.id);
  };

  const handleModuleDelete = (id: string) => {
    setModules(prev => prev.filter(m => m.id !== id));
    setSelectedModuleId("");
  };

  const handleModuleUpdate = (id: string, updates: Partial<Module>) => {
    setModules(prev => prev.map(m => 
      m.id === id ? { ...m, ...updates } : m
    ));
  };

  // Navigation handlers
  const handleSave = () => {
    const designData = JSON.stringify(modules, null, 2);
    console.log("Saving habitat design:", designData);
    // In a real app, this would save to backend or local storage
    alert("Design saved! (This is a prototype - check console for data)");
  };

  const handleLoad = () => {
    console.log("Load design triggered");
    // In a real app, this would show a file picker or design library
    alert("Load functionality would show saved designs");
  };

  const handleExport = () => {
    const designData = {
      modules,
      metadata: {
        totalModules: modules.length,
        moduleTypes: Array.from(new Set(modules.map(m => m.type))),
        exportedAt: new Date().toISOString()
      }
    };
    console.log("Exporting design:", designData);
    // In a real app, this would generate downloadable files
    alert("Export would generate downloadable files (see console)");
  };

  const handleReset = () => {
    if (confirm("Are you sure you want to reset the entire design?")) {
      setModules([]);
      setSelectedModuleId("");
      setSelectedPaletteType(undefined);
      console.log("Design reset");
    }
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      <NavigationBar
        onSave={handleSave}
        onLoad={handleLoad}
        onExport={handleExport}
        onReset={handleReset}
      />
      
      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel - Module Palette */}
        <div className="p-4 border-r bg-card/30">
          <ModulePalette
            onModuleSelect={setSelectedPaletteType}
            selectedType={selectedPaletteType}
          />
        </div>
        
        {/* Center - Design Canvas */}
        <div 
          className="flex-1 relative"
          onClick={handleCanvasClick}
        >
          <DesignCanvas
            modules={modules}
            selectedModuleId={selectedModuleId}
            onModuleSelect={handleModuleSelect}
            onModuleMove={handleModuleMove}
            onModuleAdd={handleModuleAdd}
          />
          
          {/* Instructions overlay */}
          {selectedPaletteType && (
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-card border rounded-lg px-4 py-2 shadow-lg z-10">
              <p className="text-sm text-center">
                Click anywhere on the canvas to place a{" "}
                <span className="font-medium capitalize">
                  {selectedPaletteType.replace(/([A-Z])/g, ' $1').toLowerCase()}
                </span>{" "}
                module
              </p>
            </div>
          )}
        </div>
        
        {/* Right Panel - Properties */}
        <div className="p-4 border-l bg-card/30">
          <PropertiesPanel
            selectedModule={selectedModule}
            onModuleDelete={handleModuleDelete}
            onModuleUpdate={handleModuleUpdate}
          />
        </div>
      </div>
      
      {/* Status Bar */}
      <div className="px-4 py-2 border-t bg-card text-sm text-muted-foreground flex justify-between">
        <span>
          Modules: {modules.length} | Selected: {selectedModule ? `${selectedModule.type} (${selectedModule.id})` : 'None'}
        </span>
        <span>
          {selectedPaletteType ? `Placing: ${selectedPaletteType}` : 'Ready'}
        </span>
      </div>
    </div>
  );
}