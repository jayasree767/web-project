# Space Habitat Design Prototype - Visual Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern space/aerospace applications like SpaceX mission control interfaces and NASA's visualization tools, combined with clean design system principles for optimal usability.

## Core Design Elements

### A. Color Palette
**Dark Mode Primary** (space-themed):
- Background: 220 25% 8% (deep space blue-black)
- Surface: 220 20% 12% (module panels)
- Primary: 200 100% 60% (bright space blue)
- Accent: 280 80% 65% (cosmic purple - used sparingly)
- Text: 0 0% 95% (near white)
- Success: 140 70% 55% (oxygen green)
- Warning: 35 90% 60% (energy orange)

**Light Mode** (clean laboratory):
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Primary: 220 100% 45%
- Text: 220 15% 20%

### B. Typography
**Google Fonts**: 
- Primary: Inter (clean, technical readability)
- Accent: JetBrains Mono (for technical specifications)

**Hierarchy**:
- Headings: Inter Bold 24px/20px/16px
- Body: Inter Regular 14px
- Technical data: JetBrains Mono 12px

### C. Layout System
**Tailwind Spacing**: Primary units of 2, 4, 6, and 8
- Component padding: p-4, p-6
- Element margins: m-2, m-4
- Grid gaps: gap-4, gap-6
- Large sections: p-8

### D. Component Library

**Navigation**:
- Clean top navigation bar with module categories
- Sidebar tool panel with drag-and-drop components
- Floating action buttons for primary actions (save, export)

**Habitat Designer**:
- Central canvas with grid background (subtle space dots pattern)
- Draggable module components with connection points
- Hover states show module specifications
- Selected modules have glowing outline (primary color)

**Module Components**:
- Living quarters: Rounded rectangles with bed icons
- Laboratories: Hexagonal shapes with science icons
- Storage: Square modules with inventory icons
- Life support: Circular with system status indicators

**Control Panels**:
- Right sidebar with module properties
- System status cards with subtle gradients
- Toggle switches for habitat systems
- Numerical inputs with clean borders

**Data Visualization**:
- Simple progress bars for resource levels
- Clean metric cards with large numbers
- Status indicators using color-coded dots

### E. Visual Effects
**Minimal Animations**:
- Smooth drag-and-drop with subtle shadow lift
- Gentle hover transitions (0.2s ease)
- Module snap-to-grid with soft bounce
- NO excessive animations or distracting effects

## Space-Themed Enhancements

**Background Elements**:
- Subtle star field pattern (very low opacity dots)
- Optional Earth/Mars backdrop toggle
- Clean grid overlay for precise module placement

**Module Styling**:
- Rounded corners for friendly feel
- Subtle drop shadows for depth
- Clean icons from Heroicons or similar
- Connection lines between linked modules

**Export Features**:
- Clean screenshot functionality
- Simple PDF export with module specifications
- Sharing via generated links

## User Experience Principles
- **Intuitive Drag-and-Drop**: Clear visual feedback during module placement
- **Progressive Disclosure**: Advanced features available but not overwhelming
- **Touch-Friendly**: Large interaction targets for tablet use
- **Accessibility**: High contrast ratios, clear focus states
- **Performance**: Lightweight interactions, no heavy 3D rendering

The design should feel like a professional space mission planning tool - clean, purposeful, and inspiring while remaining highly functional for habitat design exploration.